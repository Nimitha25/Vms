package com.cg.vms.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VmsApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
